import CommonTable from "../CommonTable";

const AuthenticationLogs = () => {
  return (
    <>
      <CommonTable
        title={"Authentication Logs List"}
        search={"Search by Value"}
        header={""}
      />
    </>
  );
};
export default AuthenticationLogs;
