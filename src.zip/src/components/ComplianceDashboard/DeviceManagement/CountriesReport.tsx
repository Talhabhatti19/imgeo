import CommonTable from "../CommonTable";

const CountriesReport = () => {
  return (
    <>
      <CommonTable title={"Countries Report"} />
    </>
  );
};
export default CountriesReport;
