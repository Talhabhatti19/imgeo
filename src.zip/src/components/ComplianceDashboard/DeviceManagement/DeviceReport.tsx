import CommonTable from "../CommonTable";

const DeviceReport = () => {
  return (
    <>
      <CommonTable title={"Devices List"} search={"Search by User Name"} />
    </>
  );
};
export default DeviceReport;
