import CommonTable from "../CommonTable";

const BrowserReport = () => {
  return (
    <>
      <CommonTable title={"Browsers List"} />
    </>
  );
};
export default BrowserReport;
