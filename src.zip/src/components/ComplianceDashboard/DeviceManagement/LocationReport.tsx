import CommonTable from "../CommonTable";

const LocationReport = () => {
  return (
    <>
      <CommonTable title={"Locations Report"} />
    </>
  );
};
export default LocationReport;
