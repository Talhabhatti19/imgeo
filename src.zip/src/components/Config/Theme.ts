export const theme = {
  // appBackgroundColor: "",
  // sideBarmenuBackgroundColor: "#F6F6F6",
  // sidebarTextColor: "black",
  // headerColor: {
  //   backgroundColor: "#F6F6F6",
  // },
  // color: {
  //   headingTextColor: "",
  // },
  // cards: {
  //   cardsBackgroundColor: "",
  //   cardsTextColor: "",
  // },
  // table: {
  //   backgroundColor: "#004D72",
  //   headingColor: "white",
  //   bodyTextColor: "black",
  // },
};
