export const sideBarUtils = {};
export function setSideBarUtils(data) {
   sideBarUtils = data
}