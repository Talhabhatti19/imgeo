import { authSlice } from "./apisSlice";

const { actions } = authSlice;
export { actions };
